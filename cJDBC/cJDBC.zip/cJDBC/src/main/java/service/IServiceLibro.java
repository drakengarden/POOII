package service;public interface IServiceLibro {
}
