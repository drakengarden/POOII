package model;public class Libro {
}
